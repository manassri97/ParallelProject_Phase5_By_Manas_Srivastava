package com.capgemini;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Customer;
import com.capgemini.exceptions.InsufficientWalletBalanceException;
import com.capgemini.exceptions.PhoneNumberAlreadyExist;
import com.capgemini.exceptions.TransactionFailedException;
import com.capgemini.exceptions.WalletAccountDoesNotExist;
import com.capgemini.service.WalletServiceImpl;

@RestController

public class MyController {
	
	@Autowired
	WalletServiceImpl walletServiceImpl;
	
	Customer customer;
	
	@RequestMapping(method=RequestMethod.POST, value="/addCustomer/{name}/{mobileNo}/{balance}")
	public String createAccount(@PathVariable  String name,@PathVariable String mobileNo,@PathVariable BigDecimal balance )  {
		
		try {
			walletServiceImpl.createAccount(name, mobileNo,balance);
			return "Wallet Created Successfully";
		} catch (PhoneNumberAlreadyExist e) {
			return e.getMessage();
		} catch (SQLException e) {
			return e.getMessage();
		}
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/getBalance/{mobileNo}")
	public String showBalance(@PathVariable String mobileNo) {
		try {
			Customer customer = walletServiceImpl.showBalance(mobileNo);
			return String.valueOf(customer.getWallet().getBalance());
		} catch (WalletAccountDoesNotExist e) {
			return e.getMessage();
		} catch (SQLException e) {
			return e.getMessage();
		}
		}
	
	@RequestMapping(method=RequestMethod.POST, value="/depositBalance/{mobileNo}/{amount}")
	public String depositBalance(@PathVariable String mobileNo ,@PathVariable BigDecimal amount) {
		try {
			walletServiceImpl.depositAmount(mobileNo, amount);
			return "Amount Deposited Successfully"; 
		} catch (WalletAccountDoesNotExist e) {
			return e.getMessage();
		} catch (TransactionFailedException e) {
			return e.getMessage();
		} catch (SQLException e) {
			return e.getMessage();
		}
		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/withdrawBalance/{mobileNo}/{amount}")
	public String withdrawBalance(@PathVariable String mobileNo ,@PathVariable BigDecimal amount) {
		try {
			walletServiceImpl.withdrawAmount(mobileNo, amount);
			return "Amount Withdrawn Successfully";
		} catch (InsufficientWalletBalanceException e) {
			return e.getMessage();
		} catch (WalletAccountDoesNotExist e) {
			return e.getMessage();
		} catch (TransactionFailedException e) {
			return e.getMessage();
		} catch (SQLException e) {
			return e.getMessage();
		}	
		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/fundTransfer/{sourceMobileNo}/{targetMobileNo}/{amount}")
	public String fundTransfer(@PathVariable String sourceMobileNo ,@PathVariable String targetMobileNo ,@PathVariable BigDecimal amount) {
		 try {
			walletServiceImpl.fundTransfer(sourceMobileNo, targetMobileNo, amount);
			return "Fund Transfered Successfully"; 
		} catch (InsufficientWalletBalanceException e) {
			return e.getMessage();
		} catch (WalletAccountDoesNotExist e) {
			return e.getMessage();
		} catch (TransactionFailedException e) {
			return e.getMessage();
		} catch (SQLException e) {
			return e.getMessage();
		}
		 
		}
	

}