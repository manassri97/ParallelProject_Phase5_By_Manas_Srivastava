package com.capgemini.exceptions;

public class ConnectionNotEstablished extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConnectionNotEstablished(String string) {
		super(string);
	}
	

}
