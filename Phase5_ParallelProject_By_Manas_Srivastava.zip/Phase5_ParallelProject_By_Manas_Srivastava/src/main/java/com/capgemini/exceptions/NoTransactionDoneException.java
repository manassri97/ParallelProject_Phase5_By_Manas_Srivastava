package com.capgemini.exceptions;

public class NoTransactionDoneException extends Exception{

	public NoTransactionDoneException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
